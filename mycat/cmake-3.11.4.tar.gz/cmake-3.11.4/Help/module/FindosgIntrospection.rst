.. cmake-module:: ../../Modules/FindosgIntrospection.cmake
